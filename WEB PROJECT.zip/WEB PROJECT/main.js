// Define an array to store cart items
let cartItems = [];

// Function to add an item to the cart
function addToCart(bookTitle, bookPrice) {
    const newItem = {
        title: bookTitle,
        price: bookPrice,
    };
    cartItems.push(newItem);
    updateCart();
}

// Function to update the cart display
function updateCart() {
    const cartTotal = document.getElementById('cart-total');
    const cartList = document.getElementById('cart-items');

    // Clear the current cart display
    cartList.innerHTML = '';

    let total = 0;

    // Loop through cart items and display them
    cartItems.forEach((item) => {
        const cartItem = document.createElement('tr');
        cartItem.innerHTML = `
            <td>${item.title}</td>
            <td>$${item.price.toFixed(2)}</td>
        `;
        cartList.appendChild(cartItem);

        total += item.price;
    });

    // Update the cart total
    cartTotal.textContent = `$${total.toFixed(2)}`;
}

// Initialize the cart when the page loads
document.addEventListener('DOMContentLoaded', () => {
    updateCart();
});
